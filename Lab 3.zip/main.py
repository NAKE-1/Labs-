from JES import *
from shrinkGrow import *

# Mirrors the source picture horizontally
def mirrorHorizontal(source):
    height = getHeight(source)
    mirrorPoint = height // 2
    for x in range(getWidth(source)):
        for y in range(mirrorPoint):
            topPixel = getPixel(source, x, y)
            bottomPixel = getPixel(source, x, height - y - 1)
            color = getColor(topPixel)
            setColor(bottomPixel, color)

# Mirrors the source picture vertically
def mirrorVertical(source):
    width = getWidth(source)
    mirrorPoint = width // 2
    for y in range(getHeight(source)):
        for x in range(mirrorPoint):
            leftPixel = getPixel(source, x, y)
            rightPixel = getPixel(source, width - x - 1, y)
            color = getColor(leftPixel)
            setColor(rightPixel, color)

# Layers images on top of each other
def layer(pic):
    small = shrink(pic)
    big = grow(pic)
    
    # Create a blank canvas for layering
    width = getWidth(big)
    height = getHeight(big)
    layeredPic = makeEmptyPicture(width, height)
    
    # Copy big, original, and small images into the layeredPic
    copyInto(big, layeredPic, 0, 0)
    copyInto(pic, layeredPic, (width - getWidth(pic)) // 2, (height - getHeight(pic)) // 2)
    copyInto(small, layeredPic, (width - getWidth(small)) // 2, (height - getHeight(small)) // 2)
    
    writePictureTo(layeredPic, "!layerOutput.jpg")

# Changes the color of the top half of the picture to green
def topHalfGreen(pic):
    for y in range(getHeight(pic) // 2):
        for x in range(getWidth(pic)):
            p = getPixel(pic, x, y)
            setColor(p, makeColor(0, 255, 0))

# Changes the top right quadrant of the picture to yellow
def quad1Yellow(pic):
    for y in range(getHeight(pic) // 2):
        for x in range(getWidth(pic) // 2, getWidth(pic)):
            p = getPixel(pic, x, y)
            setColor(p, makeColor(255, 255, 0))

# Changes specific pixels in the input picture to a cyan color
def mystery(pic):
    for y in range(getHeight(pic)):
        for x in range(getWidth(pic) // 2):
            p = getPixel(pic, x, y)
            setColor(p, makeColor(0, 255, 255))

# Adds a yellow frame around the input picture
def frameIt(pic):
    width = getWidth(pic)
    height = getHeight(pic)
    for x in range(width):
        for y in range(40):  # Top frame
            p = getPixel(pic, x, y)
            setColor(p, makeColor(255, 255, 0))
        for y in range(height - 40, height):  # Bottom frame
            p = getPixel(pic, x, y)
            setColor(p, makeColor(255, 255, 0))
    for y in range(height):
        for x in range(40):  # Left frame
            p = getPixel(pic, x, y)
            setColor(p, makeColor(255, 255, 0))
        for x in range(width - 40, width):  # Right frame
            p = getPixel(pic, x, y)
            setColor(p, makeColor(255, 255, 0))

# Test code
pic = makePicture("eiffel.jpg")

# Test the mystery function
mystery(pic)
writePictureTo(pic, "!mysteryOutput.jpg")

# Test topHalfGreen
topHalfGreen(pic)
writePictureTo(pic, "!topHalfGreenOutput.jpg")

# Test quad1Yellow
quad1Yellow(pic)
writePictureTo(pic, "!quad1YellowOutput.jpg")

# Test layering function
layer(pic)

# Test frameIt function
frameIt(pic)
writePictureTo(pic, "frameItOutput.jpg")

# Test mirroring functions
mirrorHorizontal(pic)
writePictureTo(pic, "!mirrorHorizontalOutput.jpg")
mirrorVertical(pic)
writePictureTo(pic, "!mirrorVerticalOutput.jpg")
